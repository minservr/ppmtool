package io.agileintelligence.ppmtool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PpmToolFullStackApplication {

	public static void main(String[] args) {
		SpringApplication.run(PpmToolFullStackApplication.class, args);
	}

}
